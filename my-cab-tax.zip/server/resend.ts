import { Resend } from 'resend';

let connectionSettings: any;

async function getCredentials() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? 'repl ' + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
    ? 'depl ' + process.env.WEB_REPL_RENEWAL
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=resend',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  if (!connectionSettings || (!connectionSettings.settings.api_key)) {
    throw new Error('Resend not connected');
  }
  return { apiKey: connectionSettings.settings.api_key, fromEmail: connectionSettings.settings.from_email };
}

const CUSTOM_FROM_EMAIL = process.env.RESEND_FROM_EMAIL || null;
const CUSTOM_FROM_NAME = "My Cab Tax USA";

export async function getResendClient() {
  const { apiKey, fromEmail } = await getCredentials();

  const resolvedFrom = CUSTOM_FROM_EMAIL
    ? `${CUSTOM_FROM_NAME} <${CUSTOM_FROM_EMAIL}>`
    : fromEmail;

  return {
    client: new Resend(apiKey),
    fromEmail: resolvedFrom,
  };
}
